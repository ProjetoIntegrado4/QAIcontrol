# %% [markdown]
# # QAI Control - análise exploratória dos dados
# **Projeto Integrado 4 | Machine Learning | Professor Antônio Marcos Selmini**
# 
# Gustavo Carvalho; Julia Egute de Paula Machado; Pablo Perez Schmekel; Pedro Raphael Martins Perroni.
# 
# Objetivo: identificar padrões de uso, custos e limitações da base que possam apoiar a futura construção do Mapa Inteligente de Risco de Dependência de IA. Esta entrega realiza análise exploratória; não apresenta um classificador de dependência validado.
# 
# **Execução:** coloque `csv.zip` na mesma pasta deste notebook e execute todas as células em ordem. No Colab, envie `csv.zip` para a sessão antes de executar. Dependências: pandas, numpy, matplotlib e seaborn. O notebook já contém as saídas da execução realizada. Os CSVs originais não são alterados.
# 
# **Método:** seleção, diagnóstico, transformação explícita e interpretação, conforme os materiais de KDD, preparação e transformação de dados do professor. A análise usa a base completa, sem amostragem. Valores ausentes não são imputados automaticamente. Sem fonte verificável de câmbio, custos são analisados por moeda.

# %%
from pathlib import Path
import zipfile, hashlib, platform
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

BASE = Path.cwd()
ARQUIVO = BASE / 'csv.zip'
if not ARQUIVO.exists():
    raise FileNotFoundError('Coloque csv.zip na mesma pasta do notebook antes de executar.')
RESULTADOS = BASE / 'resultados'
GRAFICOS = BASE / 'graficos'
RESULTADOS.mkdir(exist_ok=True)
GRAFICOS.mkdir(exist_ok=True)
sns.set_theme(style='whitegrid', font_scale=0.95)
plt.rcParams['figure.dpi'] = 120

def mostrar(tabela):
    print(tabela.to_string(index=False))

def salvar_grafico(nome):
    plt.tight_layout()
    plt.savefig(GRAFICOS / nome, dpi=160, bbox_inches='tight')
    plt.show()
    plt.close()

with zipfile.ZipFile(ARQUIVO) as z:
    dados = {Path(nome).stem: pd.read_csv(z.open(nome), low_memory=False,
             dtype={'cost_center':'string'})
             for nome in sorted(z.namelist()) if nome.endswith('.csv')}
assinatura = hashlib.sha256(ARQUIVO.read_bytes()).hexdigest()
print('SHA-256 de csv.zip:', assinatura)
print('Python:', platform.python_version(), '| pandas:', pd.__version__,
      '| numpy:', np.__version__, '| seaborn:', sns.__version__)
print('Tabelas:', len(dados))

# %% [markdown]
# ## 1. Dimensão, ausentes e duplicidades
# Cada percentual de ausentes usa como denominador o número de linhas da própria tabela. A soma de linhas das 17 tabelas não representa quantidade de usuários ou eventos únicos. Duplicidades completas e de chaves são verificadas separadamente.

# %%
inventario = pd.DataFrame([{'tabela':n,'linhas':len(d),'colunas':len(d.columns),
                            'duplicadas_completas':int(d.duplicated().sum())}
                           for n,d in dados.items()])
mostrar(inventario)
print('Soma de linhas:', inventario.linhas.sum())
inventario.to_csv(RESULTADOS/'inventario.csv',index=False)
ausentes = pd.DataFrame([{'tabela':n,'campo':c,'ausentes':int(d[c].isna().sum()),
                          'percentual':100*d[c].isna().mean()}
                         for n,d in dados.items() for c in d.columns if d[c].isna().any()])
mostrar(ausentes.round(2))
ausentes.to_csv(RESULTADOS/'ausentes.csv',index=False)
fig, ax = plt.subplots(figsize=(10,6))
a=ausentes.sort_values('percentual')
ax.barh(a.tabela+'.'+a.campo,a.percentual,color='#427a99')
ax.set(xlabel='Ausentes (% das linhas da tabela)',title='Ausência por campo na base original',xlim=(0,100))
salvar_grafico('01_ausentes.png')

# %%
chaves = {'companies':['company_id'],'departments':['department_id'],
 'employees':['employee_id'],'ai_tools':['ai_tool_id'],'ai_models':['model_id'],
 'ai_usage_logs':['usage_id'],'ai_billing':['billing_id'],
 'ai_budgets':['company_id','cost_center','year','month'],
 'ai_licenses':['company_id','employee_id','ai_tool_id'],
 'training_records':['training_id'],'approved_ai_tools':['company_id','ai_tool_id'],
 'security_events':['event_id'],'projects':['project_id'],
 'pull_requests':['pull_request_id'],'issues':['issue_id'],'builds':['build_id'],
 'deployments':['deployment_id']}
# Nas tabelas sem ID, são combinações candidatas verificadas nesta extração.
duplicidades = pd.DataFrame([{'tabela':n,'chave_testada':', '.join(cols),
 'repeticoes':int(dados[n].duplicated(cols).sum()),
 'linhas_com_chave_ausente':int(dados[n][cols].isna().any(axis=1).sum())}
 for n,cols in chaves.items()])
mostrar(duplicidades)
duplicidades.to_csv(RESULTADOS/'duplicidades_chaves.csv',index=False)

destinos = {'company_id':('companies','company_id'),
 'department_id':('departments','department_id'),'employee_id':('employees','employee_id'),
 'ai_tool_id':('ai_tools','ai_tool_id'),'model_id':('ai_models','model_id'),
 'project_id':('projects','project_id')}
integridade=[]
for n,d in dados.items():
    for c,(destino,chave) in destinos.items():
        if c in d and n!=destino:
            observados=d[c].notna()
            invalidos=observados & ~d[c].isin(dados[destino][chave])
            integridade.append({'tabela':n,'campo':c,'destino':destino,
             'referencias_presentes':int(observados.sum()),'sem_correspondencia':int(invalidos.sum())})
integridade=pd.DataFrame(integridade)
mostrar(integridade)
integridade.to_csv(RESULTADOS/'integridade_referencial.csv',index=False)
print('Referências presentes sem correspondência:',integridade.sem_correspondencia.sum())
print('Esta checagem não substitui a validação das combinações empresa/departamento/usuário.')

# %% [markdown]
# ## 2. Significado dos valores ausentes
# O diagnóstico deve preceder a imputação. Datas de fechamento, merge ou conclusão ausentes podem registrar um evento que ainda não aconteceu. Preços por token podem não se aplicar à modalidade de licença. Sem contexto, preencher esses campos cria fatos artificiais.

# %%
for tabela,campo,status in [
 ('training_records','completion_date','completion_status'),
 ('issues','closed_at','status'),('pull_requests','merged_at','status'),
 ('ai_licenses','expiration_date','license_status'),
 ('approved_ai_tools','allowed_departments','approval_status')]:
    print('\n',tabela,':',campo)
    print(pd.crosstab(dados[tabela][status],dados[tabela][campo].isna())
          .rename(columns={False:'preenchido',True:'ausente'}).to_string())
print('\nPreços por modalidade de licenciamento:')
precos=dados['ai_models'].merge(dados['ai_tools'][['ai_tool_id','licensing_type']],
                               on='ai_tool_id',validate='many_to_one')
mostrar(precos[['licensing_type','input_price_usd_per_1k_tokens',
               'output_price_usd_per_1k_tokens']].groupby('licensing_type').agg(['count','size']).reset_index())

# %% [markdown]
# **Decisão:** preservar os nulos estruturais; não preencher datas nem notas de cursos não concluídos. Manter `review_count` ausente na análise descritiva. Para latência, criar indicador de ausência e examinar sua relação com falhas. Centros de custo sem informação permanecem identificados como ausentes. Nenhuma exclusão ou imputação é aplicada aos CSVs originais.

# %% [markdown]
# ## 3. Eventos, requisições e estatísticas descritivas
# Um evento pode agregar várias requisições: contar linhas e somar `request_count` respondem a perguntas diferentes. As estatísticas de latência usam apenas os valores observados, sem transformar ausências em zero.

# %%
uso=dados['ai_usage_logs'].copy()
uso['timestamp']=pd.to_datetime(uso['timestamp'],errors='raise')
uso['mes']=uso.timestamp.dt.to_period('M').astype(str)
uso['latencia_ausente']=uso.latency_ms.isna()
variaveis=['request_count','input_tokens','output_tokens','latency_ms']
estatisticas=uso[variaveis].describe().T.reset_index(names='variavel')
mostrar(estatisticas.round(3))
estatisticas.to_csv(RESULTADOS/'estatisticas_uso.csv',index=False)
print('Período:',uso.timestamp.min(),'até',uso.timestamp.max())
print('Eventos:',len(uso),'| Requisições:',uso.request_count.sum())
print('Colaboradores com eventos:',uso.employee_id.nunique(),
      '| Cadastrados:',len(dados['employees']))
fig,axs=plt.subplots(1,2,figsize=(10,3.8))
axs[0].hist(uso.request_count,bins=45,color='#427a99')
axs[0].set(title='Requisições por evento',xlabel='Requisições',ylabel='Eventos')
axs[1].hist(uso.input_tokens,bins=60,color='#d59a42')
axs[1].set(title='Tokens de entrada por evento',xlabel='Tokens',ylabel='Eventos (escala log)')
axs[1].set_yscale('log')
salvar_grafico('02_distribuicoes.png')

# %%
linhas=[]
for c in variaveis:
    s=uso[c].dropna();q1,q3=s.quantile([.25,.75]);iqr=q3-q1
    inferior=q1-1.5*iqr;superior=q3+1.5*iqr
    k=int(((s<inferior)|(s>superior)).sum())
    linhas.append({'variavel':c,'q1':q1,'q3':q3,'iqr':iqr,
     'limite_inferior':inferior,'limite_superior':superior,
     'sinalizados':k,'observados':len(s),'percentual':100*k/len(s)})
outliers=pd.DataFrame(linhas)
mostrar(outliers.round(3))
outliers.to_csv(RESULTADOS/'outliers_iqr.csv',index=False)
fig,ax=plt.subplots(figsize=(10,4))
ordem=dados['ai_tools'].ai_tool_id.tolist()
sns.boxplot(data=uso,x='ai_tool_id',y='request_count',order=ordem,
            showfliers=False,color='#8eb3c5',ax=ax)
ax.set(xlabel='Ferramenta (ID do catálogo)',ylabel='Requisições por evento',
       title='Distribuição por ferramenta; pontos extremos ocultos apenas no gráfico')
salvar_grafico('03_boxplot_ferramentas.png')

# %% [markdown]
# **Interpretação:** médias superiores às medianas sugerem cauda à direita. O critério IQR sinaliza valores para investigação, não comprova erro. Não removemos os extremos; a comparação por ferramenta ajuda a separar uso intenso esperado de registros que merecem revisão. Identificadores e contagens administrativas não são usados indiscriminadamente na correlação.

# %% [markdown]
# ## 4. Ferramentas, evolução temporal e status
# São apresentados rankings separados por número de eventos e quantidade de requisições. O total mensal não é previsão. A comparação histórica deve considerar mudanças no conjunto de usuários e ferramentas.

# %%
ferramentas=uso.groupby('ai_tool_id').agg(eventos=('usage_id','size'),
 requisicoes=('request_count','sum'),usuarios=('employee_id','nunique')).reset_index()
ferramentas=ferramentas.merge(dados['ai_tools'][['ai_tool_id','tool_name']],
                             on='ai_tool_id',validate='one_to_one')
ferramentas['pct_eventos']=100*ferramentas.eventos/len(uso)
ferramentas['pct_requisicoes']=100*ferramentas.requisicoes/uso.request_count.sum()
mostrar(ferramentas.sort_values('requisicoes',ascending=False).round(2))
ferramentas.to_csv(RESULTADOS/'uso_por_ferramenta.csv',index=False)
fig,axs=plt.subplots(1,2,figsize=(10,4))
for ax,col,titulo in zip(axs,['eventos','requisicoes'],['Mais eventos','Mais requisições']):
    f=ferramentas.nlargest(5,col).sort_values(col)
    ax.barh(f.tool_name,f[col],color='#427a99')
    ax.set(title=titulo,xlabel=col.capitalize())
salvar_grafico('04_ranking_ferramentas.png')

mensal=uso.groupby('mes').agg(eventos=('usage_id','size'),
 requisicoes=('request_count','sum'),usuarios=('employee_id','nunique')).reset_index()
mostrar(mensal)
mensal.to_csv(RESULTADOS/'uso_mensal.csv',index=False)
fig,ax=plt.subplots(figsize=(10,3.7))
ax.plot(mensal.mes,mensal.requisicoes,marker='o',color='#427a99')
ax.tick_params(axis='x',rotation=45)
ax.set(xlabel='Mês',ylabel='Requisições agregadas',title='Volume mensal de requisições')
salvar_grafico('05_evolucao_mensal.png')

# %%
status=uso.request_status.value_counts().rename_axis('status').reset_index(name='eventos')
status['percentual']=100*status.eventos/len(uso)
mostrar(status.round(2))
status.to_csv(RESULTADOS/'status_eventos.csv',index=False)
latencia=uso.groupby('request_status').agg(eventos=('usage_id','size'),
 ausentes=('latencia_ausente','sum'),latencia_mediana=('latency_ms','median')).reset_index()
latencia['pct_ausente']=100*latencia.ausentes/latencia.eventos
mostrar(latencia.round(2))
latencia.to_csv(RESULTADOS/'latencia_por_status.csv',index=False)
fig,axs=plt.subplots(1,2,figsize=(10,3.6))
axs[0].bar(status.status,status.percentual,color='#427a99')
axs[0].set(ylabel='% dos eventos',title='Status dos eventos')
axs[1].bar(latencia.request_status,latencia.pct_ausente,color='#d59a42')
axs[1].set(ylabel='% sem latência em cada status',title='Ausência de latência por status')
for ax in axs:ax.tick_params(axis='x',rotation=20)
salvar_grafico('06_status_latencia.png')

# %% [markdown]
# **Conclusão:** a ausência de latência concentra-se em eventos sem sucesso. A mediana calculada apenas sobre observações disponíveis não descreve necessariamente as falhas sem telemetria. Por isso, preservamos o indicador de ausência e evitamos imputação global nesta etapa. Percentuais de status referem-se a eventos, não à quantidade ponderada de requisições.

# %% [markdown]
# ## 5. Correlações
# Pearson mede associação linear; Spearman compara postos e complementa a análise diante de assimetria e extremos. Para pares envolvendo latência, são usados apenas os registros com latência observada. Nenhuma associação é interpretada como causalidade.

# %%
pearson=uso[variaveis].corr(method='pearson')
spearman=uso[variaveis].corr(method='spearman')
print('Pearson:\n',pearson.round(4).to_string())
print('\nSpearman:\n',spearman.round(4).to_string())
pearson.to_csv(RESULTADOS/'correlacao_pearson.csv')
spearman.to_csv(RESULTADOS/'correlacao_spearman.csv')
por_ferramenta=uso.groupby('ai_tool_id')[variaveis].corr().reset_index()
por_ferramenta.to_csv(RESULTADOS/'correlacao_por_ferramenta.csv',index=False)
fig,axs=plt.subplots(1,2,figsize=(10,4))
rotulos=['Requisições','Tokens entrada','Tokens saída','Latência']
for ax,corr,titulo in zip(axs,[pearson,spearman],['Pearson','Spearman']):
    sns.heatmap(corr,annot=True,fmt='.2f',vmin=-1,vmax=1,cmap='RdBu_r',
                xticklabels=rotulos,yticklabels=rotulos,ax=ax,cbar=False)
    ax.set_title(titulo)
    ax.tick_params(axis='x',rotation=35)
salvar_grafico('07_correlacoes.png')

# %% [markdown]
# **Decisão:** examinar redundância entre indicadores de tokens e requisições na futura seleção de atributos. A associação agregada entre requisições e latência não demonstra que aumentar o uso reduz o tempo de resposta; diferenças de ferramenta e modalidade podem influenciar o resultado.

# %% [markdown]
# ## 6. Custos por moeda, sem conversão não comprovada
# USD e BRL representam modalidades distintas de cobrança. Como não foi fornecida fonte verificável para as taxas anteriormente usadas, não há conversão dos lançamentos em USD. A coluna `total_cost_brl` recebe o custo original apenas para BRL; permanece ausente para USD. Também não comparamos com orçamento sem confirmação da moeda de `budget_amount`.

# %%
faturas=dados['ai_billing'].copy()
faturas['total_cost_brl']=faturas.total_cost.where(faturas.currency.eq('BRL'))
faturas['exchange_rate_brl']=np.where(faturas.currency.eq('BRL'),1.0,np.nan)
faturas['conversion_status']=np.where(faturas.currency.eq('BRL'),
 'original_em_BRL','pendente_fonte_cambio')
assert faturas.total_cost.equals(dados['ai_billing'].total_cost)
assert faturas.currency.equals(dados['ai_billing'].currency)
faturas.to_csv(RESULTADOS/'ai_billing_preservado.csv',index=False)
custos=faturas.groupby('currency').agg(lancamentos=('billing_id','size'),
 total=('total_cost','sum'),media=('total_cost','mean'),
 mediana=('total_cost','median'),minimo=('total_cost','min'),maximo=('total_cost','max')).reset_index()
mostrar(custos.round(3))
custos.to_csv(RESULTADOS/'custos_por_moeda.csv',index=False)
custo_mensal=faturas.groupby(['billing_month','currency']).total_cost.sum().unstack()
mostrar(custo_mensal.reset_index().round(2))
custo_mensal.to_csv(RESULTADOS/'custos_mensais_por_moeda.csv')
extremos_custo=[]
for moeda,g in faturas.groupby('currency'):
    s=g.total_cost;q1,q3=s.quantile([.25,.75]);iqr=q3-q1
    k=int(((s<q1-1.5*iqr)|(s>q3+1.5*iqr)).sum())
    extremos_custo.append({'moeda':moeda,'sinalizados':k,'lancamentos':len(s),
      'percentual':100*k/len(s)})
mostrar(pd.DataFrame(extremos_custo).round(2))
pd.DataFrame(extremos_custo).to_csv(RESULTADOS/'outliers_custos_por_moeda.csv',index=False)
fig,axs=plt.subplots(1,2,figsize=(10,3.7))
for ax,moeda in zip(axs,['BRL','USD']):
    ax.plot(custo_mensal.index,custo_mensal[moeda],marker='o',color='#427a99')
    ax.set(title='Custos em '+moeda,xlabel='Mês',ylabel='Total em '+moeda)
    ax.tick_params(axis='x',rotation=60)
salvar_grafico('08_custos_por_moeda.png')

# %% [markdown]
# **Limitações financeiras:** não somar BRL e USD, não comparar diretamente custos de assinaturas e consumo como se tivessem a mesma unidade e não interpretar ausência de lançamento como gasto zero. O IQR por moeda é apenas triagem; segmentação por modalidade e ferramenta deve preceder eventual exclusão.

# %% [markdown]
# ## 7. Verificações finais e decisões
# Mantivemos os originais, removemos a imputação automática indevida, quantificamos ausentes e duplicidades, descrevemos distribuições e extremos, comparamos ferramentas e meses e documentamos o tratamento das moedas. A dependência de IA permanece hipótese: alto uso, isoladamente, não prova dependência. Sem rótulo validado, não é apresentado desempenho de classificação nem um escore arbitrário como verdade observada.
# 
# Na futura modelagem, definir unidade de análise (por exemplo, usuário-mês), alvo e critérios de validação. As junções precisam respeitar a granularidade para não multiplicar linhas e custos; imputações e escalonamento para modelos devem ser ajustados apenas no treino, dentro de pipeline. A validação deve considerar o tempo e os usuários/empresas para evitar vazamento.
# 
# **Fontes:** `csv.zip` (17 CSVs originais); `Analise de variaveis do banco.pdf` (contexto e dicionário fornecidos pelo grupo); feedback do professor informado pela aluna; materiais do professor `03-KDD.pdf`, `04-Preparação de Dados (1).pdf` e `05-Transformação.pdf`. Os dados são sintéticos segundo a documentação fornecida; a geração e a representatividade externa não foram auditadas.

# %%
assert len(dados)==17
assert len(uso)==269515
assert int(uso.request_count.sum())==8310838
assert inventario.duplicadas_completas.sum()==0
assert int(uso.loc[uso.request_status.eq('success'),'latencia_ausente'].sum())==0
assert faturas.loc[faturas.currency.eq('USD'),'total_cost_brl'].isna().all()
assert hashlib.sha256(ARQUIVO.read_bytes()).hexdigest()==assinatura
print('Conferências concluídas. Originais preservados; tabelas e gráficos disponíveis.')