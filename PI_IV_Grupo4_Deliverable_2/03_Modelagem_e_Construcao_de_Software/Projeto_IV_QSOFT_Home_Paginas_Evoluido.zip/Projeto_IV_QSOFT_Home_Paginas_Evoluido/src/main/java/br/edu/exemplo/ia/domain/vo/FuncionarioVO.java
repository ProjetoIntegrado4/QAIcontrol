package br.edu.exemplo.ia.domain.vo;

import jakarta.persistence.Embeddable;

@Embeddable
public record FuncionarioVO(
        String nome,
        String cpf,
        String emailCorporativo,
        Long telefone,
        String cargo,
        String setor,
        String matricula,
        String senha,
        String statusConta
) {
    /**
     * Valida os dados. Chamado ao criar a entidade, e não no construtor do record,
     * porque o Hibernate usa o construtor ao carregar registros já gravados no banco.
     */
    public FuncionarioVO validar() {
        requireText(nome, "Nome do funcionário");
        requireText(cargo, "Cargo do funcionário");
        validateOptional(emailCorporativo, "E-mail corporativo do funcionário");
        validateOptional(telefone, "Telefone do funcionário");
        validateOptional(setor, "Setor do funcionário");
        validateOptional(matricula, "Matrícula do funcionário");
        validateOptional(senha, "Senha do funcionário");
        validateOptional(statusConta, "Status da conta do funcionário");
        return this;
    }

    public FuncionarioVO(String nome) {
        this(nome, null, null, null, "Não informado", null, null, null, "ATIVO");
    }

    public static FuncionarioVO completo(String nome, String cpf, String emailCorporativo, Long telefone,
                                         String cargo, String setor, String matricula, String senha,
                                         String statusConta) {
        requireText(cpf, "CPF do funcionário");
        requireText(emailCorporativo, "E-mail corporativo do funcionário");
        requirePositive(telefone, "Telefone do funcionário");
        requireText(setor, "Setor do funcionário");
        requireText(matricula, "Matrícula do funcionário");
        requireText(senha, "Senha do funcionário");
        requireText(statusConta, "Status da conta do funcionário");
        return new FuncionarioVO(nome, cpf, emailCorporativo, telefone, cargo, setor, matricula, senha, statusConta)
                .validar();
    }

    private static void validateOptional(String value, String field) {
        if (value != null) {
            requireText(value, field);
        }
    }

    private static void validateOptional(Long value, String field) {
        if (value != null && value <= 0) {
            throw new IllegalArgumentException(field + " deve ser um número inteiro positivo");
        }
    }

    private static void requireText(String value, String field) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(field + " obrigatório");
        }
    }

    private static void requirePositive(Long value, String field) {
        if (value == null || value <= 0) {
            throw new IllegalArgumentException(field + " deve ser um número inteiro positivo");
        }
    }

    @Override
    public String toString() {
        return "FuncionarioVO[nome=" + nome + ", cpf=" + cpf + ", emailCorporativo=" + emailCorporativo
                + ", telefone=" + telefone + ", cargo=" + cargo + ", setor=" + setor + ", matricula="
                + matricula + ", senha=[REDACTED], statusConta=" + statusConta + "]";
    }
}
