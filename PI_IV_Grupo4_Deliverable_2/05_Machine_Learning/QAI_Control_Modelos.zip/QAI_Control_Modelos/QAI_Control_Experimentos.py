# %% [markdown]
# # QAI Control - treinamento, validação e avaliação de modelos
# Projeto Integrado 4 | Machine Learning | Prof. Antônio Marcos Selmini
# Gustavo Carvalho; Julia Egute de Paula Machado; Pablo Perez Schmekel;
# Pedro Raphael Martins Perroni.
#
# **Objetivo:** prever retrabalho ou rejeição de tarefas com IA, como apoio à
# priorização de revisão humana. Não é um classificador de dependência cognitiva.
# **Fontes:** os dois ZIPs fornecidos, integralmente sintéticos. Nenhuma entrada é
# alterada. Métricas medem desempenho dentro do cenário simulado e não eficácia real.
# **Execução:** mantenha os dois ZIPs em `entrada/` ou ao lado do notebook.
# No Colab, envie os dois ZIPs para a sessão e execute todas as células.
# Dependências: pandas, numpy, scipy, scikit-learn, matplotlib, seaborn e joblib.
# O SQL de origem é lido localmente, sem acesso nem alterações ao PostgreSQL.

# %%
from pathlib import Path
import zipfile, sqlite3, re, hashlib, json, platform, time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import sklearn, joblib
from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.dummy import DummyClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
 f1_score, roc_auc_score, average_precision_score, confusion_matrix,
 roc_curve, precision_recall_curve, classification_report, brier_score_loss)

BASE = Path.cwd()
for pasta in ['resultados','graficos','modelo']:
    (BASE/pasta).mkdir(exist_ok=True)

def localizar(nome):
    for p in [BASE/'entrada'/nome, BASE/nome]:
        if p.exists(): return p
    raise FileNotFoundError('Envie '+nome+' para a sessão ou para a pasta entrada/.')

origem=localizar('synthetic_ai_usage_dataset.zip')
complemento=localizar('QAI_Control_Inovacao_PostgreSQL.zip')
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [origem,complemento]}
versoes={'Python':platform.python_version(),'pandas':pd.__version__,
         'numpy':np.__version__,'scikit-learn':sklearn.__version__}
print('Versões:',versoes)
print('SHA-256:',json.dumps(hashes,indent=2))
sns.set_theme(style='whitegrid')
plt.rcParams['figure.dpi']=120

def mostrar(df): print(df.to_string(index=False))
def figura(nome):
    plt.tight_layout()
    plt.savefig(BASE/'graficos'/nome,dpi=160,bbox_inches='tight')
    plt.show()
    plt.close()

# %% [markdown]
# ## 1. Leitura, vínculos e alvo
# O complemento é SQL PostgreSQL, mas as quatro tabelas necessárias possuem
# definições e INSERTs compatíveis com SQLite. Lemos apenas essas instruções em
# memória para recuperar os dados; não executamos o script completo nem suas views.
# Isso não valida a importação nativa do pacote em PostgreSQL.

# %%
with zipfile.ZipFile(origem) as z:
    def ler_csv(nome):
        caminho=next(p for p in z.namelist() if p.endswith('/csv/'+nome+'.csv'))
        return pd.read_csv(z.open(caminho),low_memory=False)
    logs=ler_csv('ai_usage_logs')
    ferramentas=ler_csv('ai_tools')
    cursos=ler_csv('training_records')
with zipfile.ZipFile(complemento) as z:
    sql=z.read('01_importar_postgresql.sql').decode('utf-8')
    documentacao=z.read('README_postgresql.md').decode('utf-8')
    validacao_origem=json.loads(z.read('validacao.json'))

necessarias=['innovation_processes','innovation_tasks',
             'innovation_task_usage','innovation_manual_assessments']
db=sqlite3.connect(':memory:')
for linha in sql.splitlines():
    if any(linha.startswith('CREATE TABLE '+t+'(') for t in necessarias):
        db.execute(linha)
for bloco in re.finditer(r'INSERT INTO (\w+) VALUES\n(.*?);\n',sql,re.S):
    if bloco[1] in necessarias:
        db.executescript(bloco[0])
tarefas=pd.read_sql_query('SELECT * FROM innovation_tasks',db)
processos=pd.read_sql_query('SELECT * FROM innovation_processes',db)
vinculos=pd.read_sql_query('SELECT * FROM innovation_task_usage',db)
testes=pd.read_sql_query('SELECT * FROM innovation_manual_assessments',db)
db.close()
assert len(tarefas)==52870
assert tarefas.task_id.is_unique and vinculos.task_id.is_unique and vinculos.usage_id.is_unique
assert tarefas.is_synthetic.eq(1).all()
assert vinculos.usage_id.isin(logs.usage_id).all()
for col in ['started_at','completed_at']:
    tarefas[col]=pd.to_datetime(tarefas[col],errors='raise')
logs['timestamp']=pd.to_datetime(logs['timestamp'],errors='raise')
coorte=tarefas.loc[tarefas.used_ai.eq(1)].copy()
coorte=coorte.merge(vinculos[['task_id','usage_id']],on='task_id',validate='one_to_one')
coorte=coorte.merge(logs[['usage_id','timestamp','ai_tool_id']],on='usage_id',validate='one_to_one')
coorte=coorte.merge(processos[['process_id','company_id','department_id','criticality',
 'manual_fallback_documented']],on='process_id',validate='many_to_one')
coorte=coorte.merge(ferramentas[['ai_tool_id','tool_category']],on='ai_tool_id',validate='many_to_one')
coorte=coorte.rename(columns={'timestamp':'decision_at'})
assert coorte.started_at.le(coorte.decision_at).all()
assert coorte.decision_at.lt(coorte.completed_at).all()
assert coorte.outcome.isin(['Concluida','Retrabalho','Rejeitada']).all()
coorte['alvo']=coorte.outcome.isin(['Retrabalho','Rejeitada']).astype(int)
coorte=coorte.sort_values(['decision_at','task_id']).reset_index(drop=True)
distribuicao=coorte.outcome.value_counts().rename_axis('resultado').reset_index(name='n')
distribuicao['percentual']=100*distribuicao.n/len(coorte)
mostrar(distribuicao.round(3))
distribuicao.to_csv(BASE/'resultados/distribuicao_alvo.csv',index=False)
print('Tarefas com IA:',len(coorte),'| Desfavoráveis:',coorte.alvo.sum())

# %% [markdown]
# ## 2. Atributos anteriores ao resultado
# Momento de previsão: timestamp do log vinculado, estritamente anterior à conclusão.
# Campos atuais: tipo de tarefa, ferramenta/categoria, criticidade e alternativa manual.
# Não usamos duração final, revisão atual, participação efetiva da IA, score demo,
# alertas, ações, feedback, ID pessoal ou resultado como atributos.
#
# Históricos de tarefas só incorporam conclusões estritamente anteriores ao momento
# previsto. Assume-se que outcome está disponível em completed_at, pois não há
# outcome_recorded_at; essa hipótese deve ser confirmada na aplicação real.
# Testes e cursos, que possuem apenas data, entram somente a partir do dia seguinte.
# Ausência de histórico significa ausência de registro na extração, não incapacidade.
# Cadastros de processo/ferramenta são tratados como estáveis no mock; não há versões
# históricas que permitam comprovar essa estabilidade em uma organização real.

# %%
def historico_anterior(destino,eventos,chave,data_evento,coluna_valor,prefixo,janela_dias=None):
    cont=np.zeros(len(destino),dtype=int)
    soma=np.zeros(len(destino),dtype=float)
    grupos={k:g.sort_values(data_evento) for k,g in eventos.groupby(chave,sort=False)}
    for k,idx in destino.groupby(chave,sort=False).groups.items():
        if k not in grupos: continue
        g=grupos[k]
        tempos=g[data_evento].to_numpy(dtype='datetime64[ns]')
        alvos=destino.loc[idx,'decision_at'].to_numpy(dtype='datetime64[ns]')
        fim=np.searchsorted(tempos,alvos,side='left')
        inicio=np.zeros(len(idx),dtype=int)
        if janela_dias is not None:
            inicio=np.searchsorted(tempos,alvos-np.timedelta64(janela_dias,'D'),side='left')
        acumulada=np.r_[0.0,np.cumsum(g[coluna_valor].to_numpy(dtype=float))]
        cont[idx]=fim-inicio
        soma[idx]=acumulada[fim]-acumulada[inicio]
    destino[prefixo+'_n']=cont
    destino[prefixo+'_soma']=soma
    destino[prefixo+'_taxa']=np.divide(soma,cont,out=np.full(len(destino),np.nan),where=cont>0)

hist=coorte[['task_id','employee_id','process_id','completed_at','alvo']].copy()
historico_anterior(coorte,hist,'employee_id','completed_at','alvo','hist_pessoa')
historico_anterior(coorte,hist,'process_id','completed_at','alvo','hist_processo')
historico_anterior(coorte,logs,'employee_id','timestamp','request_count','uso_30d',30)

testes['assessment_date']=pd.to_datetime(testes.assessment_date)
testes_realizados=testes.loc[testes.test_status.eq('Realizado')].copy()
testes_realizados['disponivel_em']=testes_realizados.assessment_date+pd.Timedelta(days=1)
testes_realizados['reprovado']=1-testes_realizados.test_passed
historico_anterior(coorte,testes_realizados,'employee_id','disponivel_em','reprovado','testes_previos')
concluidos=cursos.loc[cursos.completion_status.eq('Concluido') & cursos.completion_date.notna()].copy()
concluidos['disponivel_em']=pd.to_datetime(concluidos.completion_date)+pd.Timedelta(days=1)
concluidos['registro']=1
historico_anterior(coorte,concluidos,'employee_id','disponivel_em','registro','cursos_previos')
coorte['hora']=coorte.decision_at.dt.hour
coorte['dia_semana']=coorte.decision_at.dt.dayofweek

numericas=['manual_fallback_documented','hist_pessoa_n','hist_pessoa_taxa',
 'hist_processo_n','hist_processo_taxa','uso_30d_n','uso_30d_soma',
 'testes_previos_n','testes_previos_taxa','cursos_previos_n','hora','dia_semana']
categoricas=['task_type','ai_tool_id','tool_category','criticality']
atributos=numericas+categoricas
assert not set(atributos)&{'outcome','alvo','actual_duration_minutes','final_score',
 'review_result','correction_count','employee_id','process_id','task_id'}
mostrar(coorte[atributos].isna().sum().rename_axis('atributo').reset_index(name='ausentes'))
print('Atributos:',len(atributos))

# %% [markdown]
# ## 3. Separação temporal e validação em janelas crescentes
# Desenvolvimento: decisões anteriores a 01/06/2026, com resultado conhecido antes
# desse corte. Teste final: decisões em junho/julho de 2026. Validações: fevereiro,
# março, abril e maio de 2026. Em cada dobra, treino anterior ao mês de validação e
# somente resultados já conhecidos no início desse mês.
# Históricos podem ser atualizados com resultados anteriores já observados durante
# o teste; os pesos dos modelos não são retreinados. É uma simulação sequencial,
# não uma previsão simultânea de todas as tarefas feita em 01/06.

# %%
CORTE=pd.Timestamp('2026-06-01')
desenvolvimento=coorte.loc[(coorte.decision_at<CORTE)&(coorte.completed_at<CORTE)].copy().reset_index(drop=True)
teste=coorte.loc[(coorte.decision_at>=CORTE)&(coorte.decision_at<pd.Timestamp('2026-08-01'))].copy().reset_index(drop=True)
X_dev=desenvolvimento[atributos]; y_dev=desenvolvimento.alvo
X_teste=teste[atributos]; y_teste=teste.alvo
dobras=[]; descricao_dobras=[]
for mes in ['2026-02','2026-03','2026-04','2026-05']:
    inicio=pd.Timestamp(mes+'-01'); fim=inicio+pd.offsets.MonthBegin(1)
    tr=np.flatnonzero((desenvolvimento.decision_at<inicio)&(desenvolvimento.completed_at<inicio))
    va=np.flatnonzero((desenvolvimento.decision_at>=inicio)&(desenvolvimento.decision_at<fim)&(desenvolvimento.completed_at<fim))
    assert len(tr)>0 and len(va)>0
    assert desenvolvimento.loc[tr,'completed_at'].max()<inicio
    assert y_dev.iloc[tr].nunique()==2 and y_dev.iloc[va].nunique()==2
    dobras.append((tr,va))
    descricao_dobras.append({'mes_validacao':mes,'treino_n':len(tr),'validacao_n':len(va),
      'treino_positivos':int(y_dev.iloc[tr].sum()),'validacao_positivos':int(y_dev.iloc[va].sum())})
descricao_dobras=pd.DataFrame(descricao_dobras)
mostrar(descricao_dobras)
descricao_dobras.to_csv(BASE/'resultados/dobras_temporais.csv',index=False)
particoes=pd.DataFrame([{'particao':nome,'n':len(d),'positivos':int(d.alvo.sum()),
 'pct_positivo':100*d.alvo.mean(),'inicio':str(d.decision_at.min()),'fim':str(d.decision_at.max())}
 for nome,d in [('desenvolvimento',desenvolvimento),('teste',teste)]])
mostrar(particoes)
particoes.to_csv(BASE/'resultados/particoes.csv',index=False)
assert set(desenvolvimento.task_id).isdisjoint(teste.task_id)
base_exportada=coorte[['task_id','employee_id','company_id','department_id','process_id',
 'decision_at','completed_at','outcome','alvo']+atributos].copy()
base_exportada['particao']=np.where(base_exportada.decision_at<CORTE,'desenvolvimento','teste')
base_exportada.to_csv(BASE/'resultados/base_modelagem.csv',index=False)

# %% [markdown]
# ## 4. Pipelines e busca de parâmetros
# Imputação de taxas históricas indefinidas pela mediana do treino, com indicador de
# ausência; isso não modifica o banco nem preenche datas/notas originais. Categorias
# são codificadas por One-Hot. A logística recebe padronização; árvores não precisam.
# GridSearchCV usa as quatro dobras temporais explícitas, com seleção pela média
# de ROC-AUC. Não há sorteio aleatório de linhas nem acesso ao teste na seleção.
# random_state=42; duas buscas em paralelo no máximo; floresta usa uma thread por fit.

# %%
def preparar(escalar=False):
    passos=[('imputacao',SimpleImputer(strategy='median',add_indicator=True))]
    if escalar:passos.append(('escala',StandardScaler()))
    return ColumnTransformer([
      ('numericas',Pipeline(passos),numericas),
      ('categoricas',Pipeline([('imputacao',SimpleImputer(strategy='most_frequent')),
       ('onehot',OneHotEncoder(handle_unknown='ignore',sparse_output=False))]),categoricas)])

especificacoes={
 'Logistica':(LogisticRegression(max_iter=2000,random_state=42),True,
     {'modelo__C':[0.1,1.0],'modelo__class_weight':[None,'balanced']}),
 'Arvore':(DecisionTreeClassifier(class_weight='balanced',random_state=42),False,
     {'modelo__max_depth':[3,6],'modelo__min_samples_leaf':[50,200]}),
 'RandomForest':(RandomForestClassifier(n_estimators=120,class_weight='balanced_subsample',
                     random_state=42,n_jobs=1),False,
     {'modelo__max_depth':[6,12],'modelo__min_samples_leaf':[20,80]})}
buscas={}; tempos={}

def treinar(nome):
    estimador,escala,grade=especificacoes[nome]
    pipe=Pipeline([('preparo',preparar(escala)),('modelo',estimador)])
    busca=GridSearchCV(pipe,grade,scoring='roc_auc',cv=dobras,n_jobs=2,
                       refit=True,return_train_score=True,error_score='raise')
    inicio=time.perf_counter()
    busca.fit(X_dev,y_dev)
    tempos[nome]=time.perf_counter()-inicio
    buscas[nome]=busca
    tabela=pd.DataFrame(busca.cv_results_)
    tabela.to_csv(BASE/'resultados'/('grid_'+nome+'.csv'),index=False)
    print(nome,'| Melhor ROC-AUC média:',round(busca.best_score_,6))
    print('Parâmetros:',busca.best_params_,'| Segundos:',round(tempos[nome],2))
    mostrar(tabela[['params','mean_test_score','std_test_score','mean_train_score']].round(5))

# %%
treinar('Logistica')

# %%
treinar('Arvore')

# %%
treinar('RandomForest')

# %% [markdown]
# ## 5. Escolha do modelo e limiar somente na validação
# Melhor família: maior ROC-AUC média das quatro validações. Para cada família,
# buscamos limiar de 0,05 a 0,95 (passo 0,01) com maior F1 positivo nas previsões
# concatenadas fora do treino de cada dobra. Em empate, preferimos o limiar mais alto.
# Essa é uma regra experimental; não representa custo de negócio validado.
# As validações foram usadas na seleção: não são estimativa final independente.
# O teste permanece intocado até a seção seguinte. Não há calibração de probabilidades.

# %%
resumo_validacao=[]; limiares={}; oof_tabelas=[]; grades_limiar=[]
for nome,busca in buscas.items():
    linhas=[]
    for (tr,va),mes in zip(dobras,descricao_dobras.mes_validacao):
        modelo=clone(busca.best_estimator_).fit(X_dev.iloc[tr],y_dev.iloc[tr])
        prob=modelo.predict_proba(X_dev.iloc[va])[:,1]
        linhas.append(pd.DataFrame({'task_id':desenvolvimento.iloc[va].task_id.to_numpy(),
          'mes':mes,'y_real':y_dev.iloc[va].to_numpy(),'probabilidade':prob}))
    oof=pd.concat(linhas,ignore_index=True)
    grade=pd.DataFrame([{'modelo':nome,'limiar':float(t),
       'f1':f1_score(oof.y_real,oof.probabilidade>=t,zero_division=0),
       'precisao':precision_score(oof.y_real,oof.probabilidade>=t,zero_division=0),
       'recall':recall_score(oof.y_real,oof.probabilidade>=t,zero_division=0)}
       for t in np.round(np.arange(.05,.951,.01),2)])
    melhor=grade.sort_values(['f1','limiar'],ascending=[False,False]).iloc[0]
    limiares[nome]=float(melhor.limiar)
    oof['modelo']=nome;oof['limiar']=limiares[nome]
    oof_tabelas.append(oof);grades_limiar.append(grade)
    r=busca.cv_results_;j=busca.best_index_
    resumo_validacao.append({'modelo':nome,'auc_media':busca.best_score_,
     'auc_desvio':r['std_test_score'][j],'f1_validacao':melhor.f1,
     'precisao_validacao':melhor.precisao,'recall_validacao':melhor.recall,
     'limiar':limiares[nome],'tempo_busca_segundos':tempos[nome],
     'parametros':json.dumps(busca.best_params_,ensure_ascii=False)})
validacao=pd.DataFrame(resumo_validacao)
selecionado=validacao.sort_values('auc_media',ascending=False,kind='stable').iloc[0].modelo
validacao.to_csv(BASE/'resultados/resumo_validacao.csv',index=False)
pd.concat(oof_tabelas,ignore_index=True).to_csv(BASE/'resultados/previsoes_validacao.csv',index=False)
pd.concat(grades_limiar,ignore_index=True).to_csv(BASE/'resultados/busca_limiares.csv',index=False)
mostrar(validacao.round(5))
print('Modelo escolhido ANTES do teste:',selecionado)
print('Limiar escolhido:',limiares[selecionado])
referencia=DummyClassifier(strategy='prior').fit(X_dev,y_dev)
configuracao={'modelo_selecionado':selecionado,'limiar':limiares[selecionado],
 'criterio_modelo':'Maior ROC-AUC media na validacao temporal',
 'criterio_limiar':'Maior F1 positivo em validacao; empate prefere limiar maior',
 'corte_teste':'2026-06-01','classe_positiva':'Retrabalho ou Rejeitada',
 'probabilidades_calibradas':False,'atributos':atributos,
 'parametros':buscas[selecionado].best_params_}
(BASE/'modelo/configuracao.json').write_text(json.dumps(configuracao,ensure_ascii=False,indent=2))

# %% [markdown]
# ## 6. Teste final: comparação e análise de erros
# A referência usa a proporção do treino e prevê a classe majoritária no limiar 0,5.
# Cada modelo usa o limiar definido na validação. Também mostramos o corte padrão
# 0,5. A seleção não é alterada com base no teste. ROC-AUC e AP usam os escores
# contínuos. AP é average precision, resumo da curva precisão-recall.
# Brier avalia o erro quadrático das probabilidades; menor é melhor. Modelos com
# pesos de classe/limiar ajustado não são assumidos calibrados.

# %%
def metricas(y,p,t):
    prev=(p>=t).astype(int)
    tn,fp,fn,tp=confusion_matrix(y,prev,labels=[0,1]).ravel()
    return {'acuracia':accuracy_score(y,prev),
      'precisao':precision_score(y,prev,zero_division=0),
      'recall':recall_score(y,prev,zero_division=0),
      'f1':f1_score(y,prev,zero_division=0),'roc_auc':roc_auc_score(y,p),
      'average_precision':average_precision_score(y,p),
      'brier':brier_score_loss(y,p),'tn':int(tn),'fp':int(fp),'fn':int(fn),'tp':int(tp),
      'sinalizados':int(prev.sum()),'limiar':float(t)}

linhas=[]; linhas_padrao=[]; previsoes=[]; probabilidades={}
modelos_finais={'Referencia':referencia,**{n:b.best_estimator_ for n,b in buscas.items()}}
for nome,modelo in modelos_finais.items():
    prob=modelo.predict_proba(X_teste)[:,1]
    probabilidades[nome]=prob
    t=.5 if nome=='Referencia' else limiares[nome]
    linhas.append({'modelo':nome,**metricas(y_teste,prob,t)})
    linhas_padrao.append({'modelo':nome,**metricas(y_teste,prob,.5)})
    pr=teste[['task_id','employee_id','company_id','department_id','ai_tool_id','decision_at','outcome','alvo']].copy()
    pr['modelo']=nome;pr['probabilidade']=prob;pr['limiar']=t;pr['previsto']=(prob>=t).astype(int)
    previsoes.append(pr)
resultados=pd.DataFrame(linhas)
resultados.to_csv(BASE/'resultados/metricas_teste.csv',index=False)
pd.DataFrame(linhas_padrao).to_csv(BASE/'resultados/metricas_teste_limiar_050.csv',index=False)
pd.concat(previsoes,ignore_index=True).to_csv(BASE/'resultados/previsoes_teste.csv',index=False)
mostrar(resultados.round(5))
print('\nRelatório do modelo selecionado:',selecionado)
print(classification_report(y_teste,probabilidades[selecionado]>=limiares[selecionado],
      target_names=['Concluida','Retrabalho/Rejeitada'],digits=4,zero_division=0))

# %%
fig,axs=plt.subplots(1,2,figsize=(10,4))
for nome,prob in probabilidades.items():
    fpr,tpr,_=roc_curve(y_teste,prob)
    prec,rec,_=precision_recall_curve(y_teste,prob)
    r=resultados.loc[resultados.modelo.eq(nome)].iloc[0]
    axs[0].plot(fpr,tpr,label=f'{nome}: {r.roc_auc:.3f}')
    axs[1].plot(rec,prec,label=f'{nome}: AP {r.average_precision:.3f}')
axs[0].plot([0,1],[0,1],'--',color='gray')
axs[0].set(title='ROC no teste',xlabel='Taxa de falsos positivos',ylabel='Recall')
axs[1].axhline(y_teste.mean(),ls='--',color='gray')
axs[1].set(title='Precisão-recall no teste',xlabel='Recall',ylabel='Precisão')
for ax in axs:ax.legend(fontsize=8)
figura('01_roc_precisao_recall.png')

fig,axs=plt.subplots(2,2,figsize=(9,7))
for ax,(nome,prob) in zip(axs.flat,probabilidades.items()):
    t=.5 if nome=='Referencia' else limiares[nome]
    cm=confusion_matrix(y_teste,prob>=t,labels=[0,1])
    sns.heatmap(cm,annot=True,fmt='d',cbar=False,cmap='Blues',ax=ax,
      xticklabels=['Concluída','Desfavorável'],yticklabels=['Concluída','Desfavorável'])
    ax.set(title=nome+' | corte '+str(t),xlabel='Previsto',ylabel='Real')
figura('02_matrizes_confusao.png')

fig,axs=plt.subplots(1,3,figsize=(10,3.5))
for ax,col,titulo in zip(axs,['f1','recall','average_precision'],['F1 positivo','Recall positivo','Average precision']):
    ax.bar(resultados.modelo,resultados[col],color='#427a99')
    ax.set(title=titulo,ylim=(0,1));ax.tick_params(axis='x',rotation=30)
figura('03_comparacao_metricas.png')

# %% [markdown]
# ## 7. Erros por grupo e recomendações demonstrativas
# Avaliamos grupos sem trocar o modelo/limiar depois de consultar o teste.
# Não há inferência causal: sugerir revisão não demonstra que ela reduzirá retrabalho.
# O limiar foi otimizado por F1; custos e capacidade real de revisão não foram definidos.
# Os escores não são probabilidades calibradas de dependência ou de sucesso de intervenção.

# %%
pred_escolhido=probabilidades[selecionado]>=limiares[selecionado]
analise=teste.copy();analise['probabilidade']=probabilidades[selecionado]
analise['previsto']=pred_escolhido.astype(int)
analise['mes']=analise.decision_at.dt.to_period('M').astype(str)
grupos=[]
for campo in ['mes','company_id','ai_tool_id']:
    for valor,g in analise.groupby(campo):
        grupos.append({'campo':campo,'grupo':valor,'n':len(g),'positivos':int(g.alvo.sum()),
         'prevalencia':g.alvo.mean(),'precisao':precision_score(g.alvo,g.previsto,zero_division=0),
         'recall':recall_score(g.alvo,g.previsto,zero_division=0),
         'f1':f1_score(g.alvo,g.previsto,zero_division=0),
         'roc_auc':roc_auc_score(g.alvo,g.probabilidade) if g.alvo.nunique()==2 else np.nan})
por_grupo=pd.DataFrame(grupos)
por_grupo.to_csv(BASE/'resultados/metricas_por_grupo.csv',index=False)
mostrar(por_grupo.loc[por_grupo.campo.eq('mes')].round(5))
exemplos=analise[['task_id','decision_at','criticality','probabilidade','previsto','outcome']].copy()
exemplos['recomendacao']=np.where(exemplos.previsto.eq(1),
 'Priorizar revisao humana; processo critico requer atencao adicional',
 'Manter revisao prevista pela politica; previsao nao dispensa supervisao')
exemplos.to_csv(BASE/'resultados/recomendacoes_teste.csv',index=False)
mostrar(exemplos.sort_values('probabilidade',ascending=False).head(6))
print('Sinalizados:',int(pred_escolhido.sum()),'de',len(teste))

# %% [markdown]
# ## 8. Artefatos, limites e conclusões
# O modelo salvo é o selecionado pela validação, treinado até maio de 2026, com o
# limiar congelado. Não foi reajustado após o teste. A saída principal é a tabela de
# métricas e a comparação com a referência, não uma promessa de bom desempenho.
# As amostras de tarefas do mock favorecem dias com mais eventos; não estimam adoção
# ou produtividade real. Usuários/empresas podem aparecer em treino e teste porque o
# objetivo é previsão sequencial na população existente. Generalização para novos
# usuários/empresas exige outro experimento. Não há validação com a QSOFT nem teste
# real de redução de dependência. Risk Score, feedback e retorno da otimização não
# foram usados como verdade de treinamento. O componente ML complementa a inovação.
# Fontes de método: materiais do professor sobre preparação, transformação,
# validação cruzada, regressão logística, árvores/ensemble e ROC/AUC.

# %%
joblib.dump(buscas[selecionado].best_estimator_,BASE/'modelo/modelo_selecionado.joblib')
auditoria={'hashes_entrada':hashes,'versoes':versoes,'tarefas_ia':len(coorte),
 'positivos_total':int(coorte.alvo.sum()),'atributos':atributos,
 'particoes':particoes.to_dict(orient='records'),
 'dobras':descricao_dobras.to_dict(orient='records'),
 'validacao':validacao.to_dict(orient='records'),
 'teste':resultados.to_dict(orient='records'),'configuracao':configuracao,
 'hipotese_disponibilidade_outcome':'outcome disponivel em completed_at',
 'teste_sequencial_com_historico_atualizado':True}
(BASE/'resultados/auditoria.json').write_text(json.dumps(auditoria,ensure_ascii=False,indent=2,default=str))
assert len(coorte)==39204 and int(coorte.alvo.sum())==6723
assert len(resultados)==4
for r in resultados.to_dict(orient='records'):
    assert r['tn']+r['fp']+r['fn']+r['tp']==len(teste)
    assert r['fn']+r['tp']==int(y_teste.sum())
assert hashes=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [origem,complemento]}
print('Experimentos concluídos; entradas preservadas.')
print('Selecionado pela validação:',selecionado,'| Limiar:',limiares[selecionado])
print('Configuração, modelo, métricas, previsões e gráficos salvos.')


# %% [markdown]
# ## 9. Referência de sinalização total e incerteza do teste
# Os limiares escolhidos por F1 sinalizaram quase todas as tarefas. Para interpretar
# esse comportamento, acrescentamos a referência descritiva “sinalizar todas”, sem
# alterar modelos, parâmetros, limiares ou a seleção feita na validação.
# 
# Também estimamos um intervalo de ROC-AUC por bootstrap com reamostragem de
# colaboradores (300 repetições, seed 42), mantendo tarefas do mesmo colaborador
# agrupadas. Esse intervalo descreve incerteza do teste sintético e não generalização
# para empresas reais. Não usamos o intervalo para retunar o modelo.

# %%
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import (accuracy_score,precision_score,recall_score,f1_score,
 roc_auc_score,average_precision_score,confusion_matrix,brier_score_loss)

raiz=Path.cwd()
cfg=json.loads((raiz/'modelo/configuracao.json').read_text())
prev=pd.read_csv(raiz/'resultados/previsoes_teste.csv')
sel=prev.loc[prev.modelo.eq(cfg['modelo_selecionado'])].copy()
y=sel.alvo.to_numpy();p=sel.probabilidade.to_numpy()
todos=np.ones(len(y),dtype=int)
tn,fp,fn,tp=confusion_matrix(y,todos,labels=[0,1]).ravel()
ref={'modelo':'Sinalizar_todas','acuracia':accuracy_score(y,todos),
 'precisao':precision_score(y,todos),'recall':recall_score(y,todos),
 'f1':f1_score(y,todos),'roc_auc':.5,'average_precision':average_precision_score(y,todos),
 'brier':brier_score_loss(y,todos),'tn':int(tn),'fp':int(fp),'fn':int(fn),
 'tp':int(tp),'sinalizados':len(y),'limiar':.5}
comparacao=pd.concat([pd.read_csv(raiz/'resultados/metricas_teste.csv'),pd.DataFrame([ref])],ignore_index=True)
comparacao.to_csv(raiz/'resultados/comparacao_referencias.csv',index=False)
print(comparacao[['modelo','precisao','recall','f1','roc_auc','average_precision','sinalizados']].round(5).to_string(index=False))

grupos,codigos=np.unique(sel.employee_id.to_numpy(),return_inverse=True)
rng=np.random.default_rng(42)
boot=[]
for _ in range(300):
    sorteados=rng.integers(0,len(grupos),size=len(grupos))
    multiplicidades=np.bincount(sorteados,minlength=len(grupos))
    pesos=multiplicidades[codigos]
    boot.append(roc_auc_score(y,p,sample_weight=pesos))
intervalo={'metrica':'ROC-AUC do modelo selecionado','modelo':cfg['modelo_selecionado'],
 'roc_auc':roc_auc_score(y,p),'limite_025':float(np.quantile(boot,.025)),
 'limite_975':float(np.quantile(boot,.975)),
 'repeticoes':300,'unidade_bootstrap':'employee_id','colaboradores_teste':len(grupos)}
(raiz/'resultados/bootstrap_auc.json').write_text(json.dumps(intervalo,ensure_ascii=False,indent=2))
print('Bootstrap por colaborador:',json.dumps(intervalo,ensure_ascii=False))

fig,axs=plt.subplots(1,2,figsize=(10,3.5))
axs[0].bar(comparacao.modelo,comparacao.f1,color='#427a99')
axs[0].set(title='F1: modelos e referências',ylabel='F1 da classe positiva',ylim=(0,1))
axs[1].bar(comparacao.modelo,100*comparacao.sinalizados/len(y),color='#c29042')
axs[1].set(title='Carga de sinalização no teste',ylabel='% de tarefas sinalizadas',ylim=(0,105))
for ax in axs:ax.tick_params(axis='x',rotation=35)
plt.tight_layout()
plt.savefig(raiz/'graficos/04_referencias_carga_revisao.png',dpi=160,bbox_inches='tight')
plt.show();plt.close()

cfg['status']='experimental_sem_ganho_util_demonstrado'
cfg['recomendacao_uso']='Nao automatizar priorizacao com este modelo; manter como experimento documentado.'
(raiz/'modelo/configuracao.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2))
recs=pd.read_csv(raiz/'resultados/recomendacoes_teste.csv')
recs['status_experimento']='Sem ganho util demonstrado; regras de recomendacao apenas demonstrativas'
recs.to_csv(raiz/'resultados/recomendacoes_teste.csv',index=False)
print('Conclusão: a árvore sinaliza todas as tarefas e não supera essa regra em F1, precisão ou recall.')
print('ROC-AUC próxima de 0,50 e AP próxima da prevalência não sustentam priorização útil neste teste.')
print('Mantidos os resultados negativos; nenhum alvo, parâmetro ou registro foi alterado para melhorar métricas.')
