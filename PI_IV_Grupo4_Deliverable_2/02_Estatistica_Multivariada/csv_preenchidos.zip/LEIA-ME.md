# QAI Control — base consolidada

Arquivo: csv_preenchidos.zip. Versao de 22/10/2026.

## Conteudo e uso

- `csv_preenchidos/`: **30 tabelas principais**, uma por CSV: 17 originais e 13 de inovacao. Sao 491,024 registros de diferentes granularidades; essa soma nao representa eventos ou pessoas unicos.
- `historico/ai_billing2.csv`: copia historica integral da conversao antiga, fora da pasta principal. **Nao importar nem somar a ai_billing.csv.**
- `data_dictionary.md`: dicionario original, finalidade e estrutura do complemento.
- `formula_demo_v1.json`: formula existente preservada, com pesos e criterios.
- `validacao.json`: origem, hashes, contagens e resultados das verificacoes desta entrega.

Os nomes das 17 tabelas/arquivos e todos os seus cabecalhos foram preservados. Os nomes das 13 tabelas de inovacao tambem foram preservados ao exporta-las do SQL para CSV. Nenhum identificador foi renomeado e nenhuma tabela de negocio nova foi inventada.

## Escolhas confirmadas com a usuaria

1. Consolidar os CSVs em csv_preenchidos.zip, mantendo os nomes atuais.
2. Preservar a simulacao de inovacao existente. Nao foram gerados novos dados aleatorios nem forcados casos de risco alto/critico.
3. Seguir a entrega corrigida: manter nulos legitimos, valores financeiros e moedas originais, e guardar ai_billing2.csv somente no historico.

## Origem e correcoes aproveitadas

Repositorio: https://github.com/ProjetoIntegrado4/QAIcontrol

Commit da main conferido: c0bd12b34831449005771d01065c6de26817b8a3.

Foram inventariados os 348 arquivos versionados da main e os conteudos dos seus arquivos ZIP, incluindo pacotes aninhados. Os arquivos locais foram comparados aos hashes do GitHub, considerando apenas a normalizacao de finais de linha. As arvores das outras tres branches foram comparadas; main foi a referencia desta consolidacao. Arquivos compilados/imagens foram catalogados como binarios, nao interpretados como novas fontes de dados.

As 17 tabelas principais sao copias dos CSVs utilizados no MachineLearning.zip de 00_Correcoes_Deliverable_1, e seus valores foram comparados integralmente aos de synthetic_ai_usage_dataset.zip. Sao os mesmos dados usados para calcular a inovacao. Isso reaproveita a decisao documentada de preservar os nulos, em vez das imputacoes indiscriminadas do antigo csv_preenchidos.zip.

Foram restaurados da origem: datas de conclusao/fechamento/merge de eventos nao ocorridos; notas de cursos nao concluidos; expiracoes e precos por token nao aplicaveis; latencia nao capturada e contagem de revisoes nao observada. Nenhum registro observado da origem foi excluido. Nulos nao significam automaticamente erro, risco ou zero.

As 13 tabelas innovation_* foram recuperadas de Projeto_IV/Banco_de_Dados/QAI_Control_Inovacao_PostgreSQL.zip. Depois da revisao, foram corrigidos somente started_at e actual_duration_minutes de INT-0003062, INT-0033330 e INT-0041593. O inicio passou de 23h57 do dia anterior para 00h00 da data de contratacao, coincidindo com o log existente. As duracoes passaram de 63 para 60, de 51 para 48 e de 45 para 42 minutos. Conclusoes, logs, IDs e todos os demais valores foram preservados; as tarefas permanecem no mesmo mes e os scores continuam iguais. As seis alteracoes constam em validacao.json.

O notebook corrigido de Analise Preditiva tambem documenta uma conversao com PTAX/BCB e colunas derivadas. Essa transformacao nao foi confundida com ai_billing2.csv, que continua sendo a conversao antiga. Conforme a escolha confirmada, esta base principal conserva total_cost e currency originais; nao inclui novas conversoes ou taxas obtidas agora. Para custos, agrupar por moeda. A moeda de budget_amount nao esta explicitada na fonte; nao assumir comparabilidade com faturamento misto.

## Importacao e compatibilidade

Extraia o ZIP. Use **somente os 30 CSVs diretamente dentro de csv_preenchidos/** como tabelas de entrada. UTF-8 sem BOM, virgula como separador, cabecalho na primeira linha, ponto decimal e celula vazia representando NULL. Datas usam o formato ISO da fonte. Booleanos das tabelas originais seguem a fonte; os do complemento permanecem 0/1.

O importador existente do backend aceita um arquivo por tabela e permite configurar a pasta em PRODUTIVIDADE_CSV_DIR. Aponte essa configuracao para a pasta csv_preenchidos ou copie somente os 30 CSVs para dados/csv. O importador do repositorio ignora tabelas que ja possuem dados; substituir arquivos nao atualiza automaticamente um banco anteriormente carregado. Nenhum servidor existente foi alterado nesta entrega.

As inovacoes estao em CSV; este pacote nao executa nem importa SQL. O schema qai_innovation_v2 pertence ao pacote SQL anterior. O importador generico usa o schema configurado (public no codigo revisado) e nao reproduz automaticamente todas as constraints/FKs do SQL original. A integridade dos dados foi validada antes da entrega; a configuracao de constraints e a interface do mapa continuam sendo responsabilidades da aplicacao.

As views innovation_dashboard_scores e innovation_management_summary do SQL anterior nao sao tabelas novas e nao foram duplicadas como CSV. Podem ser reconstruidas na camada de consultas, se necessarias.

## Indice e limites preservados

Pesos: supervisao 30%, qualidade 20%, capacitacao 15%, governanca 15% e autonomia 20%. O calculo segue a versao demo-v1 ja existente. Minimo de 20 tarefas com IA e cobertura de 60%; indisponibilidade permanece NULL e Dados insuficientes. As tabelas de componentes permitem explicar cada score.

Ha 5.868 snapshots mensais e 29.340 componentes: 1.526 Baixo, 236 Moderado e 4.106 Dados insuficientes. Nao foram fabricados casos Alto ou Critico. Escopos de departamento, equipe e processo sao visoes alternativas e nao devem ser somados. O escopo processo considera apenas logs vinculados a tarefas amostradas.

Uso historico: junho/2025 a julho/2026. Scores foram reconstruidos retrospectivamente em setembro/2026. Alertas, acoes e feedbacks sao cenarios simulados posteriores, nao prova de efeito causal sobre meses anteriores. Novos logs nao atualizam automaticamente estes snapshots.

Toda a base e sintetica. O pacote esta completo para desenvolver e demonstrar o fluxo de inovacao definido no repositorio: tarefas e uso de IA, supervisao, autonomia, capacitacao, governanca, scores explicaveis, mapa, alertas e acompanhamento. Nao representa validacao empirica da hipotese ou feedback real da QSOFT. Foram preservados os resultados experimentais do projeto; nao foram alterados dados para melhorar metricas de Machine Learning.

## Verificacao realizada

- 79 verificacoes de chaves, vinculos e regras, mais duas verificacoes adicionais de contratacao e duracao das tarefas, sem inconsistencias.
- Verificacoes do proprio pacote SQL executadas em banco local de auditoria com sintaxe equivalente: sem inconsistencias.
- Recalculo dos 5.868 snapshots e 29.340 componentes a partir dos registros de origem: resultados iguais aos armazenados.
- Integridade SQLite e chaves internas: OK. SQLite foi usado apenas para auditoria; nao e um formato de entrega adicional.
- Todos os valores e nulos foram comparados aos registros anteriores: somente seis celulas de tres tarefas diferem, conforme as correcoes autorizadas. Os outros 29 CSVs principais, o historico e a formula permaneceram identicos em bytes. Nomes, cabecalhos, contagens e leitura fisica das linhas foram conferidos.
- Importacao nativa no PostgreSQL do grupo nao executada; nao houve conexao a esse servidor.

## Tabelas principais

| Tabela | Registros |
|---|---:|
| ai_billing | 7.025 |
| ai_budgets | 2.254 |
| ai_licenses | 5.605 |
| ai_models | 25 |
| ai_tools | 15 |
| ai_usage_logs | 269.515 |
| approved_ai_tools | 105 |
| builds | 12.414 |
| companies | 18 |
| departments | 161 |
| deployments | 1.800 |
| employees | 2.356 |
| issues | 3.455 |
| projects | 18 |
| pull_requests | 5.124 |
| security_events | 69 |
| training_records | 1.597 |
| innovation_processes | 161 |
| innovation_tasks | 52.870 |
| innovation_task_usage | 39.204 |
| innovation_reviews | 39.204 |
| innovation_manual_assessments | 10.037 |
| innovation_teams | 279 |
| innovation_team_memberships | 2.356 |
| innovation_score_versions | 1 |
| innovation_risk_scores | 5.868 |
| innovation_score_components | 29.340 |
| innovation_alerts | 70 |
| innovation_management_actions | 53 |
| innovation_manager_feedback | 25 |
