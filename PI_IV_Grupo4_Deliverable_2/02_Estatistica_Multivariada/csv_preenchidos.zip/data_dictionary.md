# Dicionário de Dados — Base Sintética de Utilização de IA em Empresas

Este pacote reúne 30 tabelas principais: 17 originais e 13 de inovação. As 17 tabelas originais descritas nas seções 1 a 17 foram geradas com seed 42; o complemento usa as regras e seeds documentadas nas seções seguintes. Todos os dados são sintéticos e não representam pessoas, empresas ou eventos reais.

Convenções gerais:
- Datas no formato `AAAA-MM-DD`; timestamps no formato `AAAA-MM-DD HH:MM:SS`.
- Campos em branco/nulos no CSV representam informação não disponível ou não aplicável — isso é intencional e reflete situações comuns em dados corporativos reais.
- As 17 tabelas originais não contêm indicadores calculados. O complemento inclui snapshots de risco, componentes e versão da fórmula, descritos adiante.

---

## 1. companies.csv
Cadastro de empresas, equivalente ao que existiria em um ERP/CRM corporativo.

| Campo | Tipo | Descrição |
|---|---|---|
| company_id | texto | Identificador único da empresa (ex: `C01`) |
| company_name | texto | Nome fictício da empresa |
| industry | texto | Setor de atuação (Tecnologia / Desenvolvimento de Software, Financeiro, Indústria, Varejo, Serviços, Marketing) |
| company_size | texto | Porte declarado (`Pequena`, `Média`, `Grande`) |
| employee_count | inteiro | Headcount total da empresa (inclui colaboradores sem acesso a sistemas de IA — nem todo headcount aparece em `employees.csv`) |

## 2. departments.csv
Estrutura organizacional (RH).

| Campo | Tipo | Descrição |
|---|---|---|
| department_id | texto | Identificador único do departamento |
| company_id | texto | FK → companies.company_id |
| department_name | texto | Nome do departamento |

## 3. employees.csv
Extrato de sistema de RH (HRIS), limitado a colaboradores com potencial acesso a sistemas corporativos/ferramentas de IA (não é o headcount total da empresa).

| Campo | Tipo | Descrição |
|---|---|---|
| employee_id | texto | Identificador único do colaborador (sem nomes reais) |
| company_id | texto | FK → companies.company_id |
| department_id | texto | FK → departments.department_id |
| job_role | texto | Cargo |
| seniority | texto | Nível de senioridade (`Junior`, `Pleno`, `Senior`, `Especialista`, `Gerente`) |
| hire_date | data | Data de contratação |
| cost_center | texto | Centro de custo (~2% nulo — inconsistência de cadastro) |
| active | booleano | Se o colaborador está ativo na base atual |

## 4. ai_tools.csv
Catálogo de ferramentas de IA, equivalente a um inventário de software (CMDB/SaaS Management).

| Campo | Tipo | Descrição |
|---|---|---|
| ai_tool_id | texto | Identificador único da ferramenta |
| tool_name | texto | Nome comercial da ferramenta |
| provider | texto | Fornecedor/fabricante |
| tool_category | texto | Categoria (Assistente Generativo, Copiloto de Desenvolvimento, IA Integrada a Produtividade, Plataforma Corporativa de IA, API de Modelo) |
| licensing_type | texto | Modelo de licenciamento (`Por usuário (assinatura)` ou `Consumo (pay-as-you-go)`) |

Observação: `T15 – Zendesk Answer Bot AI` é uma ferramenta que sai de uso ao longo do período simulado (permanece no catálogo, mas deixa de aparecer em logs/licenças recentes) — simula uma descontinuação real de produto.

## 5. ai_models.csv
Modelos disponíveis por ferramenta, equivalente às tabelas de preços públicas de provedores de IA.

| Campo | Tipo | Descrição |
|---|---|---|
| model_id | texto | Identificador único do modelo |
| ai_tool_id | texto | FK → ai_tools.ai_tool_id |
| model_name | texto | Nome do modelo |
| model_family | texto | Família do modelo (GPT, Claude, Gemini, Amazon Titan, PaLM, Codex, Proprietário) |
| input_price_usd_per_1k_tokens | decimal | Preço **sintético** por 1.000 tokens de entrada (USD). Nulo para ferramentas sem cobrança por token (licenciamento por assento) |
| output_price_usd_per_1k_tokens | decimal | Preço **sintético** por 1.000 tokens de saída (USD) |

**Os preços são fictícios e não devem ser usados como referência de mercado.**

## 6. ai_usage_logs.csv
Principal tabela de eventos de uso. Simula logs de um gateway/proxy corporativo de IA (ex.: proxy de API, plataforma de IA empresarial). Não contém conteúdo de prompts nem dados pessoais — apenas metadados técnicos.

| Campo | Tipo | Descrição |
|---|---|---|
| usage_id | texto | Identificador único do evento |
| timestamp | datetime | Data/hora do evento |
| employee_id | texto | FK → employees.employee_id |
| company_id | texto | FK → companies.company_id |
| department_id | texto | FK → departments.department_id |
| ai_tool_id | texto | FK → ai_tools.ai_tool_id |
| model_id | texto | FK → ai_models.model_id |
| application | texto | Contexto/aplicação de origem (ex: "Extensão VSCode", "Chat Web", "Add-in Outlook") |
| request_count | inteiro | Número de requisições agregadas no evento |
| input_tokens | inteiro | Tokens de entrada consumidos |
| output_tokens | inteiro | Tokens de saída gerados |
| latency_ms | inteiro | Latência média em milissegundos (nulo em ~2% dos casos — telemetria ausente, mais comum em falhas) |
| request_status | texto | `success`, `error`, `timeout` ou `rate_limited` |
| project_id | texto | FK → projects.project_id, preenchido apenas para uso de copilotos de desenvolvimento em empresas de software (~23% dos registros) |
| cost_center | texto | Centro de custo do colaborador no momento do evento (pode ser nulo) |

## 7. ai_billing.csv
Simula extrato de fatura/relatório FinOps mensal.

| Campo | Tipo | Descrição |
|---|---|---|
| billing_id | texto | Identificador único do lançamento |
| company_id | texto | FK → companies.company_id |
| billing_month | texto | Mês de referência (`AAAA-MM`) |
| provider | texto | Fornecedor cobrado |
| ai_tool_id | texto | FK → ai_tools.ai_tool_id |
| model_id | texto | FK → ai_models.model_id (nulo para cobrança por licença/assento, onde não se aplica) |
| cost_center | texto | Centro de custo (pode ser nulo) |
| usage_quantity | número | Quantidade cobrada (tokens totais para ferramentas de consumo; nº de licenças ativas para ferramentas por assento) |
| total_cost | decimal | Custo total do lançamento |
| currency | texto | `USD` (ferramentas de consumo, faturadas por provedores internacionais) ou `BRL` (ferramentas por assento, contratadas localmente) |

Nota: a mistura de moedas é proposital — reflete a realidade de empresas que pagam parte das ferramentas de IA em fatura internacional (USD) e parte via contrato/revenda local (BRL). Algumas combinações empresa/mês/ferramenta não têm lançamento (~3-4%), simulando atraso ou falha de integração de fatura — isso não foi corrigido de propósito.

## 8. ai_budgets.csv
Planejamento orçamentário por centro de custo, independente do gasto realizado.

| Campo | Tipo | Descrição |
|---|---|---|
| company_id | texto | FK → companies.company_id |
| cost_center | texto | Centro de custo orçado |
| year | inteiro | Ano de referência |
| month | inteiro | Mês de referência (1–12) |
| budget_amount | decimal | Valor orçado |

Esta tabela **não é comparada** com `ai_billing.csv` na geração — a análise de orçado vs. realizado (e eventual estouro) fica a cargo do time de projeto.

## 9. ai_licenses.csv
Simula extrato de um painel de administração de licenças SaaS (ex.: admin console de Copilot/ChatGPT Enterprise).

| Campo | Tipo | Descrição |
|---|---|---|
| company_id | texto | FK → companies.company_id |
| employee_id | texto | FK → employees.employee_id |
| ai_tool_id | texto | FK → ai_tools.ai_tool_id |
| license_type | texto | `Standard`, `Professional` ou `Enterprise` |
| assigned_date | data | Data de atribuição da licença |
| expiration_date | data | Data de expiração (nula para acordos corporativos "perpétuos"/enterprise) |
| license_status | texto | `Ativa`, `Expirada` ou `Revogada` |

Permite cruzar, posteriormente, quem tem licença atribuída vs. quem efetivamente aparece em `ai_usage_logs.csv` (não calculado aqui).

## 10. training_records.csv
Simula extrato de um LMS corporativo.

| Campo | Tipo | Descrição |
|---|---|---|
| training_id | texto | Identificador único do registro |
| employee_id | texto | FK → employees.employee_id |
| company_id | texto | FK → companies.company_id |
| course_name | texto | Nome do curso |
| course_category | texto | Categoria do curso |
| enrollment_date | data | Data de inscrição |
| completion_date | data | Data de conclusão (nula se não concluído) |
| completion_status | texto | `Concluido`, `Em Andamento`, `Nao Iniciado` ou `Abandonado` |
| score | inteiro | Nota final (0–100), preenchida apenas quando `Concluido` |
| duration_hours | decimal | Carga horária do curso |

## 11. approved_ai_tools.csv
Simula registro de comitê de governança de TI/Segurança da Informação.

| Campo | Tipo | Descrição |
|---|---|---|
| company_id | texto | FK → companies.company_id |
| ai_tool_id | texto | FK → ai_tools.ai_tool_id |
| approval_status | texto | `Aprovado`, `Bloqueado` ou `Em Avaliacao` |
| approval_date | data | Data da decisão |
| allowed_departments | texto | Lista de departamentos autorizados (ou "Todos os departamentos"); nula quando a ferramenta não está aprovada. Formatação de lista (`;` ou `,`) varia entre registros — inconsistência proposital de cadastro manual |

## 12. security_events.csv
Simula log de uma ferramenta de segurança tipo CASB/DLP.

| Campo | Tipo | Descrição |
|---|---|---|
| event_id | texto | Identificador único do evento |
| company_id | texto | FK → companies.company_id |
| employee_id | texto | FK → employees.employee_id |
| timestamp | datetime | Data/hora do evento |
| ai_tool_id | texto | FK → ai_tools.ai_tool_id |
| event_type | texto | Tipo do evento (bloqueio, alerta de DLP, uso não aprovado/Shadow AI, etc.) |
| severity | texto | `Baixa`, `Media`, `Alta` ou `Critica` |
| policy_id | texto | Identificador da política violada |
| action_taken | texto | Ação tomada pelo sistema/equipe de segurança |

## 13. projects.csv
Cadastro de projetos (apenas empresas de desenvolvimento de software), equivalente a um Jira/Azure DevOps.

| Campo | Tipo | Descrição |
|---|---|---|
| project_id | texto | Identificador único do projeto |
| company_id | texto | FK → companies.company_id |
| project_name | texto | Nome do projeto |
| project_type | texto | `Produto Interno`, `Cliente`, `Plataforma`, `Mobile` ou `API/Integracao` |
| start_date | data | Data de início |
| status | texto | `Ativo`, `Concluido` ou `Pausado` |

## 14. pull_requests.csv
Simula extrato da API do GitHub/GitLab.

| Campo | Tipo | Descrição |
|---|---|---|
| pull_request_id | texto | Identificador único do PR |
| project_id | texto | FK → projects.project_id |
| employee_id | texto | FK → employees.employee_id (autor) |
| created_at | datetime | Data/hora de criação |
| merged_at | datetime | Data/hora do merge (nulo se não mesclado) |
| status | texto | `Merged`, `Fechado sem merge` ou `Aberto` |
| files_changed | inteiro | Nº de arquivos alterados |
| additions | inteiro | Linhas adicionadas |
| deletions | inteiro | Linhas removidas |
| review_count | inteiro | Nº de revisões (nulo em ~5% dos casos — dado não capturado) |

Nenhum campo indica se o código foi "gerado por IA" — essa correlação deve ser explorada futuramente cruzando com `ai_usage_logs.csv`.

## 15. issues.csv
Simula extrato de sistema de tickets (Jira).

| Campo | Tipo | Descrição |
|---|---|---|
| issue_id | texto | Identificador único do issue |
| project_id | texto | FK → projects.project_id |
| employee_id | texto | FK → employees.employee_id (responsável) |
| issue_type | texto | `Bug`, `Feature`, `Debito Tecnico` ou `Chore` |
| priority | texto | `Baixa`, `Media`, `Alta` ou `Critica` |
| created_at | datetime | Data/hora de criação |
| closed_at | datetime | Data/hora de fechamento (nulo se aberto) |
| status | texto | `Aberto`, `Em Andamento` ou `Fechado` |

## 16. builds.csv
Simula log de pipeline de CI (Jenkins/GitHub Actions).

| Campo | Tipo | Descrição |
|---|---|---|
| build_id | texto | Identificador único do build |
| project_id | texto | FK → projects.project_id |
| timestamp | datetime | Data/hora da execução |
| status | texto | `Sucesso` ou `Falha` |
| duration | inteiro | Duração em segundos |
| tests_executed | inteiro | Nº de testes executados |
| tests_failed | inteiro | Nº de testes que falharam |

## 17. deployments.csv
Simula log de pipeline de CD.

| Campo | Tipo | Descrição |
|---|---|---|
| deployment_id | texto | Identificador único do deploy |
| project_id | texto | FK → projects.project_id |
| timestamp | datetime | Data/hora do deploy |
| environment | texto | `Dev`, `Staging` ou `Producao` |
| status | texto | `Sucesso`, `Falha` ou `Revertido` |

---

## Relacionamentos (chaves estrangeiras)

- `companies.company_id` ← departments, employees, ai_billing, ai_budgets, ai_licenses, training_records, approved_ai_tools, security_events, projects, ai_usage_logs
- `departments.department_id` ← employees, ai_usage_logs
- `employees.employee_id` ← ai_usage_logs, ai_licenses, training_records, security_events, pull_requests, issues
- `ai_tools.ai_tool_id` ← ai_models, ai_usage_logs, ai_billing, ai_licenses, approved_ai_tools, security_events
- `ai_models.model_id` ← ai_usage_logs, ai_billing
- `projects.project_id` ← pull_requests, issues, builds, deployments; também referenciado por `ai_usage_logs.project_id` quando aplicável
- `cost_center` é um atributo comum (não uma FK rígida) presente em employees, ai_usage_logs, ai_billing e ai_budgets, útil para cruzamentos financeiros/organizacionais

## Como as diferenças de comportamento emergem (sem colunas de indicador)

Nenhuma tabela informa diretamente se uma empresa é "madura" ou "avançada" em IA. As diferenças de intensidade de uso, velocidade de adoção, cobertura de licenciamento e crescimento de custo são resultado de parâmetros usados **apenas durante a geração** (nunca exportados), como intensidade-base por empresa, viés de uso por departamento, mês de início de adoção e tendência de crescimento. Essas diferenças só se tornam visíveis analisando os registros brutos — exatamente como aconteceria com dados reais.


# Complemento de inovacao consolidado

As 13 tabelas a seguir vêm do SQL já existente no repositório. Foram corrigidos somente started_at e actual_duration_minutes de três tarefas que começavam antes da contratação; os seis valores anteriores e novos constam em validacao.json. Todos os demais valores foram preservados. Todos os registros do complemento possuem is_synthetic=1. Vazios representam NULL e não são substituídos por zero.

# QAI Control — complemento sintético para a inovação

## O que foi entregue

Dados inteiramente sintéticos para demonstrar sinais de risco de dependência de IA. Não representam pessoas, observações reais nem evidência científica. Os padrões são hipóteses de simulação plausíveis, não distribuições empiricamente calibradas.

O ZIP consolidado contém 17 tabelas originais e 13 tabelas de inovação prefixadas com `innovation_`. As cinco tabelas iniciais estão resumidas abaixo; as outras oito são equipes, integrantes, versões do índice, scores, componentes, alertas, ações e feedbacks, documentadas ao final. IDs e nomes existentes foram preservados. A única correção nos dados da inovação afeta o início e a duração de três tarefas, conforme o registro de alterações em validacao.json.

| Tabela | Linhas | Uma linha representa |
|---|---:|---|
| innovation_processes | 161 | Um processo genérico de apoio por departamento |
| innovation_tasks | 52.870 | Uma tarefa simulada, com ou sem IA |
| innovation_task_usage | 39.204 | Vínculo entre uma tarefa e um log existente |
| innovation_reviews | 39.204 | Estado da revisão de uma tarefa com IA |
| innovation_manual_assessments | 10.037 | Uma avaliação por colaborador/processo/mês amostrado |

## Arquivos e utilização

- `csv_preenchidos/`: 30 CSVs principais, cada um correspondendo à tabela de mesmo nome.
- `historico/ai_billing2.csv`: cópia da conversão antiga, somente para histórico; não importar nem somar ao faturamento principal.
- `validacao.json`: contagens, hashes, verificações e as seis alterações autorizadas.
- `formula_demo_v1.json`: definição existente do índice demonstrativo.
- `LEIA-ME.md`: instruções de importação, fontes e limites desta entrega.
- `data_dictionary.md`: este dicionário.

Este pacote entrega CSVs; não contém um banco SQLite, scripts de importação SQL ou geradores. Campos vazios representam NULL. Consulte LEIA-ME.md para a pasta configurável do importador existente e os cuidados com tabelas já carregadas.

Exemplo de vínculo após importar todas as tabelas no mesmo schema (ajuste o schema conforme seu ambiente):

```sql
SELECT t.task_id, u.company_id, u.department_id, u.ai_tool_id,
       t.ai_participation, r.review_state
FROM public.innovation_tasks t
JOIN public.innovation_task_usage x ON x.task_id=t.task_id
JOIN public.ai_usage_logs u ON u.usage_id=x.usage_id
JOIN public.innovation_reviews r ON r.task_id=t.task_id;
```

## Dicionário dos campos

Todos os registros têm `is_synthetic=1`. IDs novos não substituem IDs existentes. Booleanos usam 0/1; NULL significa desconhecido ou não aplicável. Datas/horas não possuem fuso, seguindo a base de origem.

### innovation_processes

- `process_id`: chave primária nova.
- `company_id`, `department_id`: vínculos com cadastros existentes.
- `process_name`: nome contextualizado ao departamento; processo genérico de apoio, não mapeamento real de processos.
- `criticality`: Alta para áreas financeiras, jurídicas, risco, operações bancárias, produção e manutenção; Media nas demais. Regra de demonstração, ajustável.
- `manual_fallback_documented`: existência simulada de procedimento alternativo manual; não prova competência individual.

### innovation_tasks

- `task_id`: chave primária; `process_id`: chave estrangeira interna.
- `employee_id`: executor da base; `project_id`: preservado do log, nulo quando não aplicável.
- `started_at`, `completed_at`: janela simulada; conclusão posterior ao início. Um log vinculado ocorre dentro dela.
- `task_type`: revisão técnica, comunicação, resposta ao cliente ou análise do departamento.
- `used_ai`: 1 com IA, 0 manual.
- `ai_participation`: Apoio, Parcial, Principal ou Sem IA. Não se simulou autonomia total sem evidência.
- `actual_duration_minutes`: duração SIMULADA observada no cenário, não latência de API.
- `estimated_manual_minutes`: estimativa SIMULADA; não contrafactual medido. Pode ser menor que o tempo com IA.
- `estimate_source`: explicita a natureza da estimativa.
- `outcome`: Concluida, Retrabalho ou Rejeitada; nunca interpretar todas as tarefas como sucesso.

### innovation_task_usage

- `task_id`: vínculo com tarefa; `usage_id`: log original único; chave composta task_id/usage_id.
- `purpose`: Revisar, Criar, Redigir ou Analisar.
- Ferramenta/modelo são obtidos pelo log; não são duplicados nesta tabela.

### innovation_reviews

- `review_id`: chave primária; `task_id`: uma revisão consolidada por tarefa com IA.
- `review_state`: Realizada, Nao realizada ou Desconhecida. Desconhecida não equivale a ausência de revisão.
- `reviewer_employee_id`: outro colaborador do mesmo departamento, contratado até a data da revisão.
- `reviewed_at`: posterior à conclusão da tarefa.
- `accepted_without_changes`: 1 apenas quando aprovado sem correções; 0 em correção/rejeição; NULL sem revisão conhecida.
- `correction_count`: inteiro; zero para aprovação sem alteração; NULL quando não se sabe.
- `review_minutes`: duração positiva, NULL sem revisão realizada.
- `review_result`: Aprovado, Corrigido ou Rejeitado; NULL sem revisão realizada.

### innovation_manual_assessments

- `assessment_id`: chave primária; `employee_id`, `process_id`: pessoa e processo.
- `assessment_date`: data do cenário; autorrelato não necessariamente aplicável a todas as tarefas históricas.
- `self_report_ability`: Sim, Com dificuldade ou Nao — percepção simulada.
- `test_status`: Realizado ou Nao testado.
- `test_score`: inteiro 0–100 somente com teste; não é score de dependência.
- `test_duration_minutes`: duração do teste simulado.
- `test_passed`: 1 se nota >=70, 0 caso contrário; limiar demonstrativo, não validado.
- `evidence_type`: Teste simulado ou Autorrelato simulado. Mesmo o teste NÃO é evidência real.

## Lógica e limitações da simulação

Seed fixa 20260917. Perfis individuais latentes de familiaridade com IA e habilidade manual foram sorteados separadamente: não há regra de que quem usa mais tem menor capacidade. Departamentos têm propensões diferentes de revisão. Há ruído nos testes e variação no tempo, incluindo retrabalho e tarefas nas quais IA não economiza tempo.

Foi selecionado no máximo um log por pessoa/dia, com probabilidade de seleção de 16% em cada evento até selecionar o primeiro. Logo, pessoas com mais eventos têm maior chance de aparecer. Não é amostra aleatória uniforme de colaboradores nem de tarefas. O vínculo tarefa/log é SIMULADO, não inferido a partir de conteúdo de prompt. Não implica que o log inteiro, que pode agregar requisições, corresponde a uma tarefa real identificada.

Tarefas manuais adicionais são geradas em aproximadamente 35% dos dias selecionados. Essa proporção é artificial e NÃO permite estimar a adoção real ou a fração real de trabalho com IA. A base não é controle de jornada; janelas podem se sobrepor e não devem fundamentar produtividade por hora trabalhada. Conclusão/revisão pode avançar algumas horas além do último dia dos logs.

Não foram inventados prompts, respostas, dados pessoais, fluxos entre departamentos ou autorizações reais. Os processos são genéricos e não têm histórico de alteração. Status atual do funcionário/licença não prova seu status histórico. As chaves externas para a base foram validadas por correspondência. Os CSVs não impõem constraints por si mesmos; elas dependem da configuração do banco na importação.

## Como usar na inovação

- Heatmap: departamento/processo por período, exibindo participação Principal, revisão não realizada e resultados dos testes, com quantidade de observações.
- Grafo: departamento → processo → ferramenta, com arestas baseadas nos vínculos de uso. Não representar fluxo real de trabalho entre equipes sem dados para isso.
- Revisão: Nao realizada / (Realizada + Nao realizada); divulgar Desconhecida à parte.
- Capacidade manual: testes reprovados / testes realizados. Não contar Nao testado como incapacidade.
- Concentração por ferramenta: participação dos vínculos amostrados por ferramenta; não porcentagem do universo de tarefas.
- Recomendações demonstrativas: ampliar revisão de processos críticos, oferecer capacitação e testar procedimentos alternativos.

A versão consolidada inclui innovation_risk_scores, innovation_score_components e innovation_score_versions. Os pesos, limites e critérios existentes estão em formula_demo_v1.json e representam regras de demonstração, não metodologia validada. Cada índice registra período, cobertura e componentes. Novos dados não atualizam automaticamente os snapshots. Estes mocks permitem testar interface e lógica, sem comprovar eficácia científica; treinar e testar apenas nestes dados mede principalmente as regras do gerador.

## Validação

Foram verificados integridade em banco local de auditoria, chaves, unicidade, vínculo executor/log, log dentro da janela da tarefa, início da tarefa não anterior à contratação, duração coerente, preservação dos nulos e recálculo dos scores. Contagens, hashes e alterações autorizadas estão em validacao.json. Os arquivos de origem do repositório permanecem intactos; o ZIP entregue incorpora somente as correções registradas.


# Estrutura exata das 13 tabelas em CSV


## innovation_processes

| Campo | Tipo de origem | Obrigatorio | Chave primaria |
|---|---|---|---|
| process_id | TEXT | Sim | 1 |
| company_id | TEXT | Sim |  |
| department_id | TEXT | Sim |  |
| process_name | TEXT | Sim |  |
| criticality | TEXT | Sim |  |
| manual_fallback_documented | INTEGER | Sim |  |
| is_synthetic | INTEGER | Sim |  |

## innovation_tasks

| Campo | Tipo de origem | Obrigatorio | Chave primaria |
|---|---|---|---|
| task_id | TEXT | Sim | 1 |
| process_id | TEXT | Sim |  |
| employee_id | TEXT | Sim |  |
| project_id | TEXT | Nao |  |
| started_at | TIMESTAMP | Sim |  |
| completed_at | TIMESTAMP | Sim |  |
| task_type | TEXT | Sim |  |
| used_ai | INTEGER | Sim |  |
| ai_participation | TEXT | Sim |  |
| actual_duration_minutes | INTEGER | Sim |  |
| estimated_manual_minutes | INTEGER | Sim |  |
| estimate_source | TEXT | Sim |  |
| outcome | TEXT | Sim |  |
| is_synthetic | INTEGER | Sim |  |

## innovation_task_usage

| Campo | Tipo de origem | Obrigatorio | Chave primaria |
|---|---|---|---|
| task_id | TEXT | Sim | 1 |
| usage_id | TEXT | Sim | 2 |
| purpose | TEXT | Sim |  |
| is_synthetic | INTEGER | Sim |  |

## innovation_reviews

| Campo | Tipo de origem | Obrigatorio | Chave primaria |
|---|---|---|---|
| review_id | TEXT | Sim | 1 |
| task_id | TEXT | Sim |  |
| review_state | TEXT | Sim |  |
| reviewer_employee_id | TEXT | Nao |  |
| reviewed_at | TIMESTAMP | Nao |  |
| accepted_without_changes | INTEGER | Nao |  |
| correction_count | INTEGER | Nao |  |
| review_minutes | INTEGER | Nao |  |
| review_result | TEXT | Nao |  |
| is_synthetic | INTEGER | Sim |  |

## innovation_manual_assessments

| Campo | Tipo de origem | Obrigatorio | Chave primaria |
|---|---|---|---|
| assessment_id | TEXT | Sim | 1 |
| employee_id | TEXT | Sim |  |
| process_id | TEXT | Sim |  |
| assessment_date | DATE | Sim |  |
| self_report_ability | TEXT | Sim |  |
| test_status | TEXT | Sim |  |
| test_score | INTEGER | Nao |  |
| test_duration_minutes | INTEGER | Nao |  |
| test_passed | INTEGER | Nao |  |
| evidence_type | TEXT | Sim |  |
| is_synthetic | INTEGER | Sim |  |

## innovation_teams

| Campo | Tipo de origem | Obrigatorio | Chave primaria |
|---|---|---|---|
| team_id | TEXT | Sim | 1 |
| company_id | TEXT | Sim |  |
| department_id | TEXT | Sim |  |
| team_name | TEXT | Sim |  |
| is_synthetic | INTEGER | Sim |  |

## innovation_team_memberships

| Campo | Tipo de origem | Obrigatorio | Chave primaria |
|---|---|---|---|
| employee_id | TEXT | Sim | 1 |
| team_id | TEXT | Sim |  |
| valid_from | DATE | Sim |  |
| valid_to | DATE | Nao |  |
| is_synthetic | INTEGER | Sim |  |

## innovation_score_versions

| Campo | Tipo de origem | Obrigatorio | Chave primaria |
|---|---|---|---|
| version_id | TEXT | Sim | 1 |
| version_name | TEXT | Sim |  |
| definition | TEXT | Sim |  |
| minimum_tasks | INTEGER | Sim |  |
| minimum_coverage | NUMERIC | Sim |  |
| created_at | TIMESTAMP | Sim |  |
| is_synthetic | INTEGER | Sim |  |

## innovation_risk_scores

| Campo | Tipo de origem | Obrigatorio | Chave primaria |
|---|---|---|---|
| score_id | TEXT | Sim | 1 |
| version_id | TEXT | Sim |  |
| company_id | TEXT | Sim |  |
| department_id | TEXT | Sim |  |
| team_id | TEXT | Nao |  |
| process_id | TEXT | Nao |  |
| scope_type | TEXT | Sim |  |
| period_start | DATE | Sim |  |
| period_end | DATE | Sim |  |
| task_count | INTEGER | Sim |  |
| ai_task_count | INTEGER | Sim |  |
| request_count | INTEGER | Sim |  |
| observed_users | INTEGER | Sim |  |
| intensity_percentile | NUMERIC | Sim |  |
| evidence_coverage | NUMERIC | Sim |  |
| final_score | NUMERIC | Nao |  |
| risk_level | TEXT | Sim |  |
| calculated_at | TIMESTAMP | Sim |  |
| is_synthetic | INTEGER | Sim |  |

## innovation_score_components

| Campo | Tipo de origem | Obrigatorio | Chave primaria |
|---|---|---|---|
| score_id | TEXT | Sim | 1 |
| component | TEXT | Sim | 2 |
| numerator | INTEGER | Sim |  |
| denominator | INTEGER | Sim |  |
| weight | NUMERIC | Sim |  |
| component_score | NUMERIC | Nao |  |
| available | INTEGER | Sim |  |
| source_definition | TEXT | Sim |  |
| is_synthetic | INTEGER | Sim |  |

## innovation_alerts

| Campo | Tipo de origem | Obrigatorio | Chave primaria |
|---|---|---|---|
| alert_id | TEXT | Sim | 1 |
| score_id | TEXT | Sim |  |
| created_at | TIMESTAMP | Sim |  |
| severity | TEXT | Sim |  |
| reason | TEXT | Sim |  |
| status | TEXT | Sim |  |
| closed_at | TIMESTAMP | Nao |  |
| is_synthetic | INTEGER | Sim |  |

## innovation_management_actions

| Campo | Tipo de origem | Obrigatorio | Chave primaria |
|---|---|---|---|
| action_id | TEXT | Sim | 1 |
| alert_id | TEXT | Sim |  |
| owner_employee_id | TEXT | Sim |  |
| action_type | TEXT | Sim |  |
| created_at | TIMESTAMP | Sim |  |
| due_at | TIMESTAMP | Sim |  |
| status | TEXT | Sim |  |
| completed_at | TIMESTAMP | Nao |  |
| outcome_note | TEXT | Nao |  |
| is_synthetic | INTEGER | Sim |  |

## innovation_manager_feedback

| Campo | Tipo de origem | Obrigatorio | Chave primaria |
|---|---|---|---|
| feedback_id | TEXT | Sim | 1 |
| score_id | TEXT | Sim |  |
| reviewer_employee_id | TEXT | Sim |  |
| submitted_at | TIMESTAMP | Sim |  |
| clarity_rating | INTEGER | Sim |  |
| usefulness_rating | INTEGER | Sim |  |
| decision_support_rating | INTEGER | Sim |  |
| agrees_with_classification | INTEGER | Sim |  |
| comment | TEXT | Sim |  |
| evidence_type | TEXT | Sim |  |
| is_synthetic | INTEGER | Sim |  |


# Finalidade das oito tabelas adicionais


Todos os registros têm `is_synthetic=1`.

### innovation_teams

`team_id` (PK), `company_id`, `department_id`, `team_name`. Equipes sintéticas de até 12 integrantes dentro de cada departamento, agrupados por cargo/ID para reprodutibilidade. Não representam organograma real.

### innovation_team_memberships

`employee_id` (PK), `team_id` (FK), `valid_from` (contratação original), `valid_to` (NULL). Hipótese simplificadora: uma equipe estável por funcionário durante o histórico. O status atual inativo não permite inferir data de desligamento. Modelo não cobre transferências/recontratações; para isso, ampliar a chave para empregado/data inicial e impedir sobreposição de intervalos.

### innovation_score_versions

`version_id` (PK), `version_name`, `definition` (JSON serializado em TEXT com regras e pesos), `minimum_tasks`, `minimum_coverage`, `created_at`. Apenas demo-v1 foi criada. Alterações futuras devem usar novo ID, sem sobrescrever a versão histórica.

### innovation_risk_scores

`score_id` (PK), `version_id` (FK), `company_id`, `department_id`, `team_id` (FK opcional), `process_id` (FK opcional), `scope_type` (department/team/process), `period_start`, `period_end`, `task_count`, `ai_task_count`, `request_count`, `observed_users`, `intensity_percentile`, `evidence_coverage`, `final_score` (0–100 ou NULL), `risk_level`, `calculated_at`.

Uma linha por unidade/competência/versão. Departamentos, equipes e processos são visões alternativas dos mesmos dados: nunca somar os três escopos. O schema tem restrição de unicidade da competência e unidade. `calculated_at` é a data da reconstrução retrospectiva, não uma afirmação de que o score já existia no mês observado.

### innovation_score_components

`score_id` (FK), `component` (PK composta), `numerator`, `denominator`, `weight`, `component_score`, `available`, `source_definition`. Permite explicar e recalcular o resultado. Ausência de dados produz NULL, não zero. Cobertura é a soma dos pesos disponíveis, não confiança estatística.

### innovation_alerts

`alert_id` (PK), `score_id` (FK único), `created_at`, `severity`, `reason`, `status`, `closed_at`. Apenas scores departamentais >=35 geram alertas, evitando alertas duplicados de equipe/processo sobre o mesmo conjunto. Regra demonstrativa. Competência consta no motivo.

### innovation_management_actions

`action_id` (PK), `alert_id` (FK), `owner_employee_id`, `action_type`, `created_at`, `due_at`, `status`, `completed_at`, `outcome_note`. Responsável é um colaborador ativo da mesma área, não necessariamente gerente. Há alertas sem ação, ações planejadas, em andamento e concluídas. Conclusão não prova redução de risco; esse efeito não foi fabricado.

### innovation_manager_feedback

`feedback_id` (PK), `score_id` (FK), `reviewer_employee_id`, `submitted_at`, `clarity_rating`, `usefulness_rating`, `decision_support_rating` (1–5), `agrees_with_classification` (0/1), `comment`, `evidence_type`. Respostas incluem discordância e notas baixas. Avaliador é representante simulado da área, não se afirma que todos possuem cargo de gerente. Não foi coletado feedback de pessoa real ou da QSOFT.

